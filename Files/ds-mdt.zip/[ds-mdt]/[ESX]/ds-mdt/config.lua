Config = {}

Config.ESXVersion = "Legacy" --- choose your version of esx server. only use this two options 1. Legacy 2. Other

Config.Policejobs = {
    'police',
    'bcso',
    'pranger',
    'doc'
}

Config.Judgegrade = 0

Config.LawyerJob = 'lawyer'

Config.MDTCommand = "mdt"