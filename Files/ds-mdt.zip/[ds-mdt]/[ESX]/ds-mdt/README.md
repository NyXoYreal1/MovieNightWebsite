MDT For QBCore and ESX by Dolaji's Scripts

[Installation]
Docs: https://docs.dolajiscripts.com/resources/ds-mdt

[Report a bug]
If you encounter a bug/issue with the resource, feel free to join the official discord and submit a ticket! (https://discord.gg/KRXuF3j).

[Notes]
This resource is targeted toward ESX and QBCore(New) servers. However, with enough effort, it is possible to get this to work with
other frameworks as long as you are willing to change the necessary events - contact me om discord if you are using different frameworks.