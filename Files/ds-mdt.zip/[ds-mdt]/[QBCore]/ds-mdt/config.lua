Config = {}

Config.Policejobs = {
    'police',
    'bcso',
    'pranger',
    'doc'
}

Config.LawyerJob = 'lawyer'

Config.MDTCommand = "mdt"

Config.Judgegrade = 0